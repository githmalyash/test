public class StackApplication {
    private int maxSize; 
    private int[] stackData;
    private int top; 

  

    public StackApplication(int s) {
        maxSize = s;
        stackData = new int[maxSize];
        top = -1;
    } 

    public boolean isEmpty() {
        return (top == -1);
    }

    public boolean isFull() {
        return (top == maxSize - 1);
    }

    public void push(int j) {
        if (!isFull()) {
            stackData[++top] = j;
            System.out.println("Pushed: " + j);
        } else {
            System.out.println("Stack is full. Cannot push " + j);
        }
    }

    public int pop() {
        if (!isEmpty()) {
            int poppedItem = stackData[top--];
            return poppedItem;
        } else {
            return -1; 
        }
    }

    public int peek() {
        if (!isEmpty()) {
            return stackData[top];
        } else {
            return -1; 
        }
    }

    public void display() {
        if (!isEmpty()) {
            System.out.print("Stack: ");
            for (int i = 0; i <= top; i++) {
                System.out.print(stackData[i] + " ");
            }
            System.out.println();
        } else {
            System.out.println("Stack is empty.");
        }
    }
    
    public int searchNode(int value) {
        for (int i = 0; i <= top; i++) {
            if (stackData[i] == value) {
                return i; 
            }
        }
        return -1; 
    }
    
    public void displaySearchResult(int value) {
        int index = searchNode(value);
        if (index != -1) {
            System.out.println("Value " + value + " found at index " + index);
        } else {
            System.out.println("Value " + value + " not found in the stack.");
        }
    }
} 
