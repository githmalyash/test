public class Node{
	String data;
	Node next;
}